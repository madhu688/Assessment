<?php $__env->startComponent('mail::message'); ?>

Welcome! You have Registered Successfully..

<?php $__env->startComponent('mail::button', ['url' => '']); ?>

Open
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.aliases.Notification')); ?>

<?php echo $__env->renderComponent(); ?>
